
<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const usuarios = ref([])
const creados = ref([])
const pagina = ref(0)
const total = ref(0)
const error = ref('')
const nuevo = ref({ firstName: '', lastName: '', email: '', age: '' })

async function cargarUsuarios() {
  try {
    error.value = ''
    const res = await axios.get('https://dummyjson.com/users', {
      params: { limit: 10, skip: pagina.value * 10 }
    })
    usuarios.value = res.data.users
    total.value = res.data.total
  } catch (e) {
    error.value = 'Error al cargar usuarios'
    console.error(e)
  }
}

async function crearUsuario() {
  try {
    error.value = ''
    const res = await axios.post('https://dummyjson.com/users/add', {
      ...nuevo.value, age: Number(nuevo.value.age)
    })
    creados.value.unshift(res.data)
    nuevo.value = { firstName: '', lastName: '', email: '', age: '' }
  } catch (e) {
    error.value = 'Error al crear usuario'
    console.error(e)
  }
}

function cambiarPagina(n) {
  pagina.value += n
  cargarUsuarios()
}

onMounted(cargarUsuarios)
</script>

<template>
  <main>
    <h1>Gestión de usuarios</h1>
    <h2>Crear usuario</h2>
    <form @submit.prevent="crearUsuario">
      <input v-model="nuevo.firstName" placeholder="Nombre" required>
      <input v-model="nuevo.lastName" placeholder="Apellido" required>
      <input v-model="nuevo.email" type="email" placeholder="Email" required>
      <input v-model="nuevo.age" type="number" min="1" placeholder="Edad" required>
      <button>Crear usuario</button>
    </form>
    <p v-if="error">{{ error }}</p>
    <h2>Usuarios creados</h2>
    <p v-for="(u, i) in creados" :key="i">
      {{ u.firstName }} {{ u.lastName }} - {{ u.email }}
    </p>
    <h2>Usuarios de DummyJSON</h2>
    <p v-for="u in usuarios" :key="u.id">
      {{ u.firstName }} {{ u.lastName }} - {{ u.email }}
    </p>
    <button :disabled="pagina === 0" @click="cambiarPagina(-1)">Anterior</button>
    Página {{ pagina + 1 }}
    <button :disabled="(pagina + 1) * 10 >= total" @click="cambiarPagina(1)">Siguiente</button>
  </main>
</template>

<style scoped>
main { max-width: 700px; margin: 30px auto; font-family: Arial; }
form { display: grid; gap: 10px; }
input, button { padding: 10px; }
button { cursor: pointer; }
</style>

