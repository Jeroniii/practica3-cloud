

ALTER TABLE juegos
ADD COLUMN IF NOT EXISTS anio INTEGER,
ADD COLUMN IF NOT EXISTS descripcion TEXT,
ADD COLUMN IF NOT EXISTS imagen VARCHAR(500),
ADD COLUMN IF NOT EXISTS es_local BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS url VARCHAR(500);


-- INSERTAR LOS 10 VIDEOJUEGOS ORIGINALES

INSERT INTO juegos
(titulo, genero, plataforma, precio, anio,
 descripcion, imagen, es_local, url)

SELECT
    datos.titulo,
    datos.genero,
    datos.plataforma,
    datos.precio,
    datos.anio,
    datos.descripcion,
    datos.imagen,
    datos.es_local,
    datos.url

FROM (
    VALUES

    (
        'Tres-en-Raya',
        'Estrategia',
        'Web',
        0.0,
        1300,
        'El clásico juego de mesa en la pantalla. Un divertido desafío mental para alinear tres piezas y ganar puntos.',
        '/img/3enraya.png',
        TRUE,
        NULL
    ),

    (
        'Ahorcado',
        'Palabras',
        'Web',
        0.0,
        1894,
        'El clásico juego de adivinar palabras en la pantalla. Un divertido desafío para evitar la horca y sumar puntos.',
        '/img/ahorcado.png',
        FALSE,
        'https://poki.com/es/g/hangman'
    ),

    (
        'Memory Cards',
        'Memoria',
        'Web',
        0.0,
        1959,
        'El clásico juego de memoria en la pantalla. Un divertido desafío de encontrar parejas para obtener puntos.',
        '/img/memorygame.png',
        FALSE,
        'https://www.memozor.com/'
    ),

    (
        'Dinosaur Game',
        'Arcade',
        'Web',
        0.0,
        2014,
        'El clásico juego del dinosaurio en la pantalla. Un divertido desafío de saltar obstáculos y conseguir puntos.',
        '/img/dinosaur.png',
        FALSE,
        'https://chromedino.com/'
    ),

    (
        'Flappy Bird',
        'Arcade',
        'Web',
        0.0,
        2013,
        'El clásico juego del pájaro en la pantalla. Un divertido desafío de esquivar tuberías para hacer puntos.',
        '/img/flappybird.png',
        FALSE,
        'https://flappybird.io/'
    ),

    (
        'Snake',
        'Arcade',
        'Web',
        0.0,
        1976,
        'El clásico juego de la serpiente en la pantalla. Un divertido desafío de comer manzanas y ganar puntos.',
        '/img/snake.png',
        FALSE,
        'https://playsnake.org/'
    ),

    (
        'Pac-Man',
        'Arcade',
        'Web',
        0.0,
        1980,
        'El clásico juego del comecocos en la pantalla. Un divertido desafío de escapar de fantasmas para sumar puntos.',
        '/img/pacman.png',
        FALSE,
        'https://freepacman.org/'
    ),

    (
        'Pong',
        'Deportes',
        'Web',
        0.0,
        1972,
        'El clásico juego de tenis en la pantalla. Un divertido desafío de devolver la pelota y anotar puntos.',
        '/img/pong.png',
        FALSE,
        'https://ponggame.org/'
    ),

    (
        'Space Invaders',
        'Arcade',
        'Web',
        0.0,
        1978,
        'El clásico juego de naves en la pantalla. Un divertido desafío de disparar a alienígenas para hacer puntos.',
        '/img/spaceinvaders.png',
        FALSE,
        'https://freeinvaders.org/'
    ),

    (
        'Tetris',
        'Puzle',
        'Web',
        0.0,
        1984,
        'El clásico juego de bloques en la pantalla. Un divertido desafío de encajar piezas para ganar puntos.',
        '/img/tetris.png',
        FALSE,
        'https://tetris.com/play-tetris'
    )

) AS datos (
    titulo,
    genero,
    plataforma,
    precio,
    anio,
    descripcion,
    imagen,
    es_local,
    url
)

WHERE NOT EXISTS (
    SELECT 1
    FROM juegos
    WHERE juegos.titulo = datos.titulo
);


