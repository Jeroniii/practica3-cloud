 
import os

from flask import Flask, jsonify , request
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv
import hmac
from functools import wraps
from flask_cors import CORS


#app.py es el archivo principal del 
# backend. Es el encargado de iniciar el servidor Flask, conectarse con PostgreSQL y gestionar los videojuegos.

#En otras palabras, es el programa que permite consultar, añadir, modificar y eliminar videojuegos de la base de datos.

# Leer la configuración del archivo .env

load_dotenv()

app = Flask(__name__)

# Permitir peticiones desde Vue
CORS(app, resources={
    r"/juegos*": {
        "origins": ["http://localhost:5173", "http://127.0.0.1:5173"],
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["Content-Type", "X-API-Key"]
    }
})

# Configurar la conexión con PostgreSQL
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ["DATABASE_URL"]
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)


# Clave de acceso para modificar videojuegos
API_KEY = os.environ["API_KEY"]

def requiere_api_key(funcion):

    @wraps(funcion)
    def comprobar_clave(*args, **kwargs):

        clave_recibida = request.headers.get("X-API-Key", "")

        if not hmac.compare_digest(
            clave_recibida, API_KEY
        ):
            return jsonify({
                "error": "No autorizado"
            }), 401

        return funcion(*args, **kwargs)

    return comprobar_clave


# Modelo de la tabla de videojuegos
class Juego(db.Model):
    __tablename__ = "juegos"

    id = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(150), nullable=False)
    genero = db.Column(db.String(100), nullable=False)
    plataforma = db.Column(db.String(100), nullable=False)
    precio = db.Column(db.Float, nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "titulo": self.titulo,
            "genero": self.genero,
            "plataforma": self.plataforma,
            "precio": self.precio
        }
    
    
# GET - Obtener todos los videojuegos
@app.route("/juegos", methods=["GET"])
#No añadimos @requiere_api_key en get ya que consultar videojuegos tiene que ser público

def listar_juegos():
    juegos = db.session.execute(
        db.select(Juego).order_by(Juego.id)
    ).scalars().all()

    resultado = [juego.to_dict() for juego in juegos]

    return jsonify(resultado), 200


# POST - Añadir un videojuego
@app.route("/juegos", methods=["POST"])

@requiere_api_key #solamente quien tenga la clave pueda añadir juegos.
def crear_juego():

    datos = request.get_json(silent=True)

    if not isinstance(datos, dict):
        return jsonify({
            "error": "Debes enviar un objeto JSON"
        }), 400

    # Comprobar campos obligatorios
    campos = ["titulo", "genero", "plataforma", "precio"]

    if any(campo not in datos for campo in campos):
        return jsonify({
            "error": "Faltan campos obligatorios"
        }), 400

    if any(
        not isinstance(datos[campo], str)
        or not datos[campo].strip()
        for campo in ["titulo", "genero", "plataforma"]
    ):
        return jsonify({
            "error": "Los campos de texto no pueden estar vacíos"
        }), 400

    precio = datos["precio"]

    if (
        isinstance(precio, bool)
        or not isinstance(precio, (int, float))
        or not 0 <= precio <= 1000000
    ):
        return jsonify({
            "error": "El precio debe ser un número válido"
        }), 400

    nuevo_juego = Juego(
        titulo=datos["titulo"].strip(),
        genero=datos["genero"].strip(),
        plataforma=datos["plataforma"].strip(),
        precio=float(precio)
    )

    db.session.add(nuevo_juego)
    db.session.commit()

    return jsonify(nuevo_juego.to_dict()), 201


# PUT - Editar un videojuego
@app.route("/juegos/<int:id>", methods=["PUT"])

@requiere_api_key

def editar_juego(id):

    juego = db.get_or_404(Juego, id)

    datos = request.get_json(silent=True)

    if not isinstance(datos, dict):
        return jsonify({
            "error": "Debes enviar un objeto JSON"
        }), 400

    campos = ["titulo", "genero", "plataforma", "precio"]

    if any(campo not in datos for campo in campos):
        return jsonify({
            "error": "Faltan campos obligatorios"
        }), 400

    if any(
        not isinstance(datos[campo], str)
        or not datos[campo].strip()
        for campo in ["titulo", "genero", "plataforma"]
    ):
        return jsonify({
            "error": "Los campos de texto no pueden estar vacíos"
        }), 400

    precio = datos["precio"]

    if (
        isinstance(precio, bool)
        or not isinstance(precio, (int, float))
        or not 0 <= precio <= 1000000
    ):
        return jsonify({
            "error": "El precio debe ser un número válido"
        }), 400

    juego.titulo = datos["titulo"].strip()
    juego.genero = datos["genero"].strip()
    juego.plataforma = datos["plataforma"].strip()
    juego.precio = float(precio)

    db.session.commit()

    return jsonify(juego.to_dict()), 200


# DELETE - Eliminar un videojuego
@app.route("/juegos/<int:id>", methods=["DELETE"])
@requiere_api_key
def eliminar_juego(id):

    juego = db.get_or_404(Juego, id)

    db.session.delete(juego)
    db.session.commit()

    return jsonify({
        "mensaje": "Videojuego eliminado correctamente"
    }), 200





# Ruta para comprobar que Flask funciona
@app.route("/")
def inicio():
    return jsonify({
        "mensaje": "Servidor Flask funcionando"
    })


# Ruta para comprobar PostgreSQL
@app.route("/comprobar-bd")
def comprobar_bd():
    try:
        with db.engine.connect() as conexion:
            conexion.execute(db.text("SELECT 1"))

        return jsonify({
            "mensaje": "Conexión con PostgreSQL correcta"
        })

    except Exception:
        app.logger.exception("Error de conexión con PostgreSQL")

        return jsonify({
            "error": "No se pudo conectar con PostgreSQL"
        }), 500



if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        print("Tablas creadas correctamente")

    app.run(debug=True)


