
import os
import unittest
import requests
from dotenv import load_dotenv

#Envía una petición GET al servidor Flask.
#Recibe la respuesta.
#Comprueba que el servidor devuelve el código 200, que significa que la petición se ha realizado correctamente.

load_dotenv()

URL = "http://127.0.0.1:5000"
HEADERS = {
    "X-API-Key": os.environ["API_KEY"]
}

class TestAPI(unittest.TestCase):

    def test_crud_juegos(self):

        # 1. GET público
        respuesta = requests.get(
            f"{URL}/juegos", timeout=5
        )
        self.assertEqual(respuesta.status_code, 200)
        self.assertIsInstance(respuesta.json(), list)
        print("GET correcto")

        # 2. POST sin autenticación
        datos = {
            "titulo": "Juego de prueba",
            "genero": "Acción",
            "plataforma": "PC",
            "precio": 20
        }

        respuesta = requests.post(
            f"{URL}/juegos",
            json=datos,
            timeout=5
        )
        self.assertEqual(respuesta.status_code, 401)
        print("Autenticación correcta")

        # 3. POST con autenticación
        respuesta = requests.post(
            f"{URL}/juegos",
            json=datos,
            headers=HEADERS,
            timeout=5
        )
        self.assertEqual(respuesta.status_code, 201)

        id_juego = respuesta.json()["id"]
        print("POST correcto")

        try:
            # 4. PUT
            datos_modificados = {
                "titulo": "Juego modificado",
                "genero": "Aventura",
                "plataforma": "PS5",
                "precio": 35
            }

            respuesta = requests.put(
                f"{URL}/juegos/{id_juego}",
                json=datos_modificados,
                headers=HEADERS,
                timeout=5
            )
            self.assertEqual(respuesta.status_code, 200)
            self.assertEqual(
                respuesta.json()["titulo"],
                "Juego modificado"
            )
            print("PUT correcto")

            # 5. DELETE
            respuesta = requests.delete(
                f"{URL}/juegos/{id_juego}",
                headers=HEADERS,
                timeout=5
            )
            self.assertEqual(respuesta.status_code, 200)
            print("DELETE correcto")

            # 6. Comprobar eliminación
            respuesta = requests.get(
                f"{URL}/juegos",
                timeout=5
            )
            self.assertFalse(
                any(j["id"] == id_juego for j in respuesta.json())
            )
            print("Eliminación comprobada")

        finally:
            # Limpieza si falla alguna comprobación
            requests.delete(
                f"{URL}/juegos/{id_juego}",
                headers=HEADERS,
                timeout=5
            )


if __name__ == "__main__":
    unittest.main()
