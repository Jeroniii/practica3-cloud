
import axios from 'axios'

// Conexión con nuestro servidor Flask
const api = axios.create({
  baseURL: 'http://127.0.0.1:5000'
})

// Obtener todos los videojuegos
export const obtenerJuegos = () => {
  return api.get('/juegos')
}

// Añadir un videojuego
export const crearJuego = (juego, apiKey) => {
  return api.post('/juegos', juego, {
    headers: { 'X-API-Key': apiKey }
  })
}

// Editar un videojuego
export const editarJuego = (id, juego, apiKey) => {
  return api.put(`/juegos/${id}`, juego, {
    headers: { 'X-API-Key': apiKey }
  })
}

// Eliminar un videojuego
export const eliminarJuego = (id, apiKey) => {
  return api.delete(`/juegos/${id}`, {
    headers: { 'X-API-Key': apiKey }
  })
}
