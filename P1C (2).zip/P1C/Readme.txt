1. Instrucciones para ejecutar el código

La práctica está desarrollada utilizando Vue 3 para el frontend,
Flask para el backend y PostgreSQL como sistema de gestión de bases de datos.

1.1. Requisitos previos

Para ejecutar la aplicación es necesario tener instalados:

Python 3.

Node.js y npm.

PostgreSQL.

pgAdmin 4.

Visual Studio Code.

1.2. Ejercicio 1: Vue 3 + Axios + DummyJSON

Este ejercicio permite consultar una lista de usuarios desde una API externa y crear usuarios mediante un formulario.

Para ejecutarlo:

Abrir una terminal en la carpeta vue_ej1_P1C.

Instalar las dependencias:

npm install

Iniciar el servidor Vue:

npm run dev

Abrir la dirección indicada en la terminal.

La aplicación utiliza Axios para realizar peticiones GET y POST a DummyJSON.

La creación de usuarios es simulada, ya que DummyJSON no guarda permanentemente los nuevos registros.

1.3. Ejercicio 2: Configuración de PostgreSQL

Para configurar la base de datos se realizaron los siguientes pasos:

Descargar e instalar PostgreSQL junto con pgAdmin 4.

Durante la instalación, configurar una contraseña para el usuario postgres.

Utilizar el puerto 5432, que es el puerto predeterminado de PostgreSQL.

Abrir pgAdmin 4 y conectarse al servidor PostgreSQL.

Crear una base de datos llamada videojuegos_db.

También se puede crear desde el Query Tool, conectado a una base de datos existente:

CREATE DATABASE videojuegos_db;

Una vez creada la base de datos, el backend Flask utiliza SQLAlchemy para definir el modelo Juego y crear la tabla mediante:

with app.app_context():
    db.create_all()

La tabla contiene los datos necesarios para gestionar los videojuegos: identificador, título, 
género, plataforma, precio, año, descripción, imagen, indicador de juego local y URL.

Si la tabla ya existía con menos columnas, se añadieron los campos adicionales ejecutando:

ALTER TABLE juegos
ADD COLUMN IF NOT EXISTS anio INTEGER,
ADD COLUMN IF NOT EXISTS descripcion TEXT,
ADD COLUMN IF NOT EXISTS imagen VARCHAR(500),
ADD COLUMN IF NOT EXISTS es_local BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS url VARCHAR(500);

Carga de los datos iniciales

Los diez videojuegos originales de la P1B se introdujeron mediante un script SQL ejecutado desde pgAdmin 4:

Tres-en-Raya

Ahorcado

Memory Cards

Dinosaur Game

Flappy Bird

Snake

Pac-Man

Pong

Space Invaders

Tetris

Para reproducir esta carga, ejecutar el archivo SQL de inserción de videojuegos incluido con la entrega.

Se puede comprobar el resultado mediante:

SELECT * FROM juegos ORDER BY id;

1.4.  Ejecutar el backend Flask

Abrir una terminal dentro de la carpeta del backend P1C.

Instalar las dependencias:

py -m pip install -r requirements.txt

Crear un archivo .env en la misma carpeta que app.py, con las siguientes variables:

DATABASE_URL=postgresql+psycopg2://postgres:CONTRASEÑA@localhost:5432/videojuegos_db
API_KEY=CLAVE_PRIVADA

Sustituir CONTRASEÑA por la contraseña configurada en PostgreSQL y CLAVE_PRIVADA por una clave privada para acceder a las operaciones protegidas.

Iniciar Flask:

py app.py

El servidor se ejecutará normalmente en:

http://127.0.0.1:5000



Esta dirección permite obtener todos los videojuegos almacenados en PostgreSQL mediante una petición GET.

1.5. Ejecutar los tests del backend

Con Flask en funcionamiento, abrir una segunda terminal en la carpeta del backend y ejecutar:

py test_api.py

El script comprueba el funcionamiento de las operaciones GET, POST, PUT y DELETE y verifica que las operaciones protegidas rechazan peticiones sin autenticación.

Si todas las comprobaciones son correctas, el resultado final será OK.

Los tests funcionan de forma independiente al frontend Vue.

1.6.  Conectar Vue con Flask

Abrir otra terminal en la carpeta p1_juego, correspondiente al frontend de videojuegos de la P1B adaptado.

Instalar las dependencias:

npm install

Iniciar la aplicación:

npm run dev

Abrir la dirección que muestre Vite, normalmente:

http://localhost:5173/

Es necesario mantener Flask ejecutándose simultáneamente en el puerto 5000.

La aplicación utiliza Axios para comunicarse con el backend y permite gestionar los videojuegos mediante las operaciones:



GET

POST

PUT

DELETE


Los cambios realizados se almacenan en PostgreSQL y pueden comprobarse desde pgAdmin 4.

2. Mecanismo de autenticación implementado

Para proteger la API RESTful desarrollada con Flask se ha utilizado un sistema de autenticación basado en una API Key.

Este mecanismo permite diferenciar entre las operaciones públicas de consulta y las operaciones de modificación de videojuegos.

2.1. Funcionamiento

La clave de acceso se almacena en el archivo .env del backend:

API_KEY=CLAVE_PRIVADA

Cuando un cliente intenta añadir, editar o eliminar un videojuego, debe incluir la clave en la cabecera HTTP:

X-API-Key: CLAVE_PRIVADA

Flask comprueba que la clave recibida coincide con la configurada en el servidor.

Si la clave es correcta, permite ejecutar la operación. Si la clave no existe o es incorrecta, devuelve una respuesta HTTP 
401 Unauthorized.

2.2. Permisos de acceso


Consultar videojuegos (GET)

Pública

Añadir videojuegos (POST)

Requiere API Key

Editar videojuegos (PUT)

Requiere API Key

Eliminar videojuegos (DELETE)

Requiere API Key

La autenticación se implementa mediante un decorador de Python llamado requiere_api_key,
que comprueba la cabecera HTTP antes de ejecutar las funciones protegidas.

2.3. Justificación del sistema elegido

Se ha elegido la autenticación mediante API Key por su sencillez de implementación y
porque permite cumplir el requisito de proteger las operaciones de modificación de la API RESTful.

No ha sido necesario desarrollar un sistema completo de registro e inicio de sesión de usuarios.

No obstante, se trata de una solución básica orientada al desarrollo y las pruebas locales. 
Una aplicación desplegada públicamente debería utilizar HTTPS, 
autenticación individual de usuarios y un sistema de autorización más completo.

La clave privada no debe incluirse directamente en el código público de Vue ni publicarse en repositorios.

3. Conclusión

La práctica permite utilizar una API externa mediante Vue y Axios, 
desarrollar una API RESTful propia con Flask y PostgreSQL, y conectar el frontend con el backend para gestionar videojuegos.

Además, se ha incorporado un mecanismo básico de autenticación mediante API Key y 
un script de pruebas automatizadas que permite comprobar la funcionalidad del backend sin depender del frontend.




4. Soluciones para poder subir imágenes y capturas

Actualmente, la aplicación de videojuegos utiliza rutas de imágenes almacenadas en la base de datos PostgreSQL.
Para permitir que los usuarios puedan subir capturas o imágenes al añadir nuevos videojuegos, se podría implementar 
un endpoint que recibiera las imágenes desde el frontend Vue mediante Axios . Flask comprobaría el formato y 
el tamaño de los archivos y los almacenaría en una carpeta del servidor . En PostgreSQL se guardaría únicamente la 
ruta de cada imagen asociada al videojuego seleccionado.

